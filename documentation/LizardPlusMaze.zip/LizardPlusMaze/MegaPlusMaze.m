classdef MegaPlusMaze < handle
    
    properties (Access = private)
        ui;
        mainWindow
        arduinoSerial = ArduinoSerial('COM3');%COM3 on pylon PC /COM5 on plexon PC
        %arduinoSerial = ArduinoSerial('/dev/ttyACM0');
        currentTrial;
        currentHeader;
        currentPath = '.';
        
        datePrefix %Generated when header is edited
        
        %Arduino events
        EVENT_HANDSHAKE = 0;
        EVENT_SELECT_START_ARM = 1;
        EVENT_SELECT_TARGET_ARM = 2;
        EVENT_OPEN_DOOR = 3;
        EVENT_CLOSE_DOOR = 4;
        EVENT_SELECT_SENSOR = 5;
        EVENT_START_TRIAL = 6;
        EVENT_STOP_TRIAL = 7;
        EVENT_DISABLE_ARMS = 8;
        EVENT_DISABLE_SENSORS = 9;
        EVENT_ERROR = 10;
        EVENT_COUNT = 11;
    end
    
    
    methods
        function obj = MegaPlusMaze(varargin)
            %Create main window here
            obj.mainWindow = figure('Position', [400, 400, 900, 650],...
                'CloseRequestFcn', @obj.on_windowCloseRequested);
            
            %Pass handle of main Window to UI as a parent
            obj.ui = MegaPlusMazeUi(obj.mainWindow);
            
            %Connect events from UI
            addlistener(obj.ui, 'event_start', @obj.on_start);
            addlistener(obj.ui, 'event_manualReward', @obj.on_manualReward);
            addlistener(obj.ui, 'event_stop', @obj.on_stop);
            addlistener(obj.ui, 'event_setup', @obj.on_setup);
            addlistener(obj.ui, 'event_newTrial', @obj.on_event_newTrial);
            addlistener(obj.ui, 'event_newHeader', @obj.on_event_newHeader);
            addlistener(obj.ui, 'event_path', @obj.on_event_path);
            
            %Initialize header and table
            s = date;
            
            %Set default header values
            %Day, Experimenter, AnimalID, Task Type, Number of trials,
            %Sensor, Training phase, Temp, Comment
            obj.ui.setHeaderData({s, '', NaN, 'Manual', 20, 1, 2, NaN, ''});
            
            %Generate a table (defaults to manual)
            obj.generateTrialTable(); %Generate trial sequence
        end
        
        %Object destructor
        function delete(obj)
            delete(obj.arduinoSerial);
        end
        
        %The start button was pressed
        function on_start(obj, ~, ~)
            if ~obj.ui.isStart
                tic
                %Trial Start
                
                obj.arduinoSerial.write(obj.EVENT_START_TRIAL, 0);
                obj.arduinoSerial.write(obj.EVENT_OPEN_DOOR,  obj.currentTrial.startArm);
                obj.ui.isStart = true;
                obj.ui.isStop = false;
            end
        end
        
        %The manual reward button was pressed
        function on_manualReward(obj, ~, ~)
            obj.arduinoSerial.write(obj.EVENT_DISABLE_SENSORS, 0);
            pause(1);
            obj.arduinoSerial.write(obj.EVENT_SELECT_SENSOR, obj.currentHeader.sensor);
        end
        
        %The stop button was pressed
        function on_stop(obj, ~, ~)
            if ~obj.ui.isStop
                t = toc;
                obj.ui.addTrialTime(t);
                obj.arduinoSerial.write(obj.EVENT_STOP_TRIAL, 0);
                obj.arduinoSerial.write(obj.EVENT_DISABLE_ARMS, 0);
                obj.saveTables();
                obj.ui.isStart = false;
                obj.ui.isStop = true;
            end
        end
        
        %The setup button was pressed
        function on_setup(obj, ~, ~)
            targetArm = obj.currentTrial.targetArm;
            startArm = obj.currentTrial.startArm;
            sensor = obj.currentHeader.sensor;
            trainingPhase = obj.currentHeader.trainingPhase; %1 or 2
            %Trial setup
            if obj.currentTrial.number==1
                for i=1:4%open all doors
                    obj.arduinoSerial.write(obj.EVENT_OPEN_DOOR, i);
                end
            end
            
            switch trainingPhase%check training phase
                case 1%close all nontarget arms ,open target arm
                    obj.arduinoSerial.write(obj.EVENT_OPEN_DOOR,targetArm);
                    for i = 1:4
                        if(i ~= targetArm)
                            obj.arduinoSerial.write(obj.EVENT_CLOSE_DOOR,i);
                        end
                    end
                    
                case 2%close only start arm
                    for i=1:4%open all doors
                        obj.arduinoSerial.write(obj.EVENT_OPEN_DOOR, i);
                    end
                    %close start arm
                    obj.arduinoSerial.write(obj.EVENT_CLOSE_DOOR, startArm);
            end
            
            obj.arduinoSerial.write(obj.EVENT_SELECT_SENSOR, sensor);
            obj.arduinoSerial.write(obj.EVENT_SELECT_START_ARM, startArm);
            obj.arduinoSerial.write(obj.EVENT_SELECT_TARGET_ARM, targetArm);
            
            pause(1);
            obj.ui.isSetup = true;
            obj.ui.isStart = false;
            obj.ui.isStop = true;
            
        end
        
        %A new trial was selected
        function on_event_newTrial(obj, ~, event)
            obj.currentTrial = event.userdata;
            obj.ui.isSetup = false;
        end
        
        %The header was changed from the GUI
        function on_event_newHeader(obj, ~, event)
            newHeader = event.userdata;
            if isempty(obj.currentHeader) ||...
                    obj.currentHeader.nTrials ~= newHeader.nTrials ||...
                    ~strcmp(obj.currentHeader.trialType, newHeader.trialType)
                obj.currentHeader = newHeader;
                obj.generateTrialTable();
            else
                obj.currentHeader = newHeader;
            end
            obj.ui.isSetup = false;
            
            obj.datePrefix = datestr(datetime('now'), 'yyyy-mm-dd-HH-MM-SS');
        end
        
        %A new path was selected
        function on_event_path(obj, ~, event)
            obj.currentPath = event.userdata;
        end
        
        %The Main Window requested to close
        function on_windowCloseRequested(obj, ~, ~)
            
            if isgraphics(obj.mainWindow, 'figure')
                obj.saveTables();
                delete(obj.mainWindow);
            end
            
            obj.delete();
        end
        
        %Save header and trial tables
        function saveTables(obj)
            [headerTable, trialTable] = obj.ui.getTable();%get current table contents
            %asign file name
            fullFileName = [obj.currentPath,filesep,obj.datePrefix(1:10),filesep,...
                'behavior',filesep,num2str(obj.currentHeader.animalID), '_', obj.datePrefix(12:19), '.mat'];
            %create data folders
            if ~isfolder([obj.currentPath,filesep,obj.datePrefix(1:10)])
                mkdir (obj.currentPath,obj.datePrefix(1:10))
                mkdir ([obj.currentPath,filesep,obj.datePrefix(1:10)],'behavior')
                mkdir ([obj.currentPath,filesep,obj.datePrefix(1:10)],'cheetah')
                mkdir ([obj.currentPath,filesep,obj.datePrefix(1:10)],'videos')
            end
            %asign table variable names
            trialTable.Properties.VariableNames={'Selected', 'Trial', 'StartArm', 'TargetArm', 'ChosenArm', 'TrialTime', 'Comment'};
            headerTable.Properties.VariableNames={'Day', 'Experimenter', 'AnimalID', 'TrialType', 'NumberOfTrials', 'Sensor', 'TrainingPhase', 'Temp', 'Comment'};
            %save file
            save(fullFileName, 'headerTable', 'trialTable');
            disp(['Wrote: ', fullFileName]);
        end
        
        %Generate an empty trial list
        function generateTrialTable(obj)
            data = repmat({false, NaN, NaN, NaN, NaN, NaN, ' '}, obj.currentHeader.nTrials, 1);
            
            %Add incrementing trial number
            for i = 1:obj.currentHeader.nTrials
                data{i, 2} = i;
            end
            
            switch obj.currentHeader.trialType
                %specific trial ordering for type 1
                case 'Manual'
                    
                case 'Random'
                    %create start and target vectors
                    startArm = nan(1, obj.currentHeader.nTrials);
                    targetArm = nan(1, obj.currentHeader.nTrials);
                    values = 1:4;
                    count = 1;
                    for i = 1:1:(obj.currentHeader.nTrials/4)
                        idx = randi(4);
                        startArm(count : count + 3) = values(idx);
                        targetArm(count : count + 3) = values(idx(end : -1 : 1));
                        count = count + 4;
                    end
                    startArm(obj.currentHeader.nTrials + 1:end) = [];%remove the 21st value
                    targetArm(obj.currentHeader.nTrials + 1:end) = [];%remove the 21st value
                    %asign to table data
                    for i=1:obj.currentHeader.nTrials
                        data{i, 3} = startArm(i);
                        data{i, 4} = targetArm(i);
                    end
                case 'Place'
                    %create start and target vectors
                    startArm = nan(1, obj.currentHeader.nTrials + 1);
                    values = [1, 3, 4];
                    count = 1;
                    for i = 1 : ceil((obj.currentHeader.nTrials + 1)/3)%21 values
                        idx = randperm(3);
                        startArm(count : count + 2) = values(idx);
                        count = count + 3;
                    end
                    startArm(obj.currentHeader.nTrials + 1 : end) = [];%remove the 21st value
                    targetArm = ones(obj.currentHeader.nTrials, 1) .* 2;%target always arm 2
                    %asign to table data
                    for i = 1:obj.currentHeader.nTrials
                        data{i, 3} = startArm(i);
                        data{i, 4} = targetArm(i);
                    end
                case 'Response'
                    %create start and target vectors
                    startArm=nan(1,obj.currentHeader.nTrials);
                    values = 1:4;
                    count = 1;
                    for i=1: ceil(obj.currentHeader.nTrials/4)%20 values
                        idx=randperm(4);
                        startArm(count : count + 3) = values(idx);
                        count=count+4;
                    end
                    startArm(obj.currentHeader.nTrials + 1 : end)=[];%remove the 21st value
                    targetArm = startArm - 1; %counter clock wise direction target arms vector
                    targetArm(targetArm==0)=4;%fix for arm 1->4
                    %asign to table data
                    for i = 1:obj.currentHeader.nTrials
                        data{i, 3} = startArm(i);
                        data{i, 4} = targetArm(i);
                    end
                case 'Cue'
                    %create start and target vectors
                    startArm = nan(1, obj.currentHeader.nTrials);
                    targetArm = nan(1, obj.currentHeader.nTrials);
                    values = [2, 4];
                    count = 1;
                    for i = 1:obj.currentHeader.nTrials
                        idx = randperm(2);
                        startArm(count : count + 1) = values(idx);
                        targetArm(count : count + 1) = values(idx(end : -1 : 1));
                        count = count + 2;
                    end
                    %asign to table data
                    for i = 1 : obj.currentHeader.nTrials
                        data{i, 3} = startArm(i);
                        data{i, 4} = targetArm(i);
                    end
                    
            end%switch
            
            obj.ui.setTrialData(data);
            obj.ui.isSetup = false;
        end%function generateTrialTable(obj)
        
    end%methods
    
end%classdef



